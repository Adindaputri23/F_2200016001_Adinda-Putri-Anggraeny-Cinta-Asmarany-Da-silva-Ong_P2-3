import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Adinda Putri Anggraeny Cinta Asmarany Da silva Ong|| 2200016001"),
          backgroundColor: Colors.blue,
        ),
        body: Center(
          child: Container(
            padding: EdgeInsets.all(30),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Container(
                  padding: EdgeInsets.all(30),
                  color: Color.fromARGB(90, 6, 52, 190),
                  child: Text(
                    'Indonesia',
                  ),
                ), //text
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text("hello"),
                    Text("baris 1"),
                    Text("baris 2"),
                    Text("baris 3"),
                  ],
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text("HALLO"),
                    Text("baris 1"),
                    Text("baris 2"),
                    Text("baris 3"),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
